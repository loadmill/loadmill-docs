# Test Maintenance

Use this scenario when updating, debugging, documenting, or syncing existing suites and flows.

## Intent and Scope

Apply this scenario for requests such as:
1. "Fix failing flow X."
2. "Refactor or optimize existing suite steps."
3. "Update assertions after API behavior change."
4. "Investigate regression in a known suite."
5. "Adjust tests because server logic changed."
6. "Update flows after API contract/header/auth changes."
7. "Check whether this Loadmill suite has pending UI changes."
8. "Update suite or flow notes."
9. "Sync this suite in Loadmill from my Git branch."

Primary focus:
1. Update existing tests to stay aligned with backend/product behavior changes.
2. Keep test intent stable while adapting request/response expectations.
3. Minimize unnecessary rewrites; patch only impacted flow sections.
4. Prevent accidental loss of unsynced Loadmill UI edits.

## Input Checklist

Collect before changes:
1. Target suite path or suite id.
2. Failing behavior, expected behavior, and urgency.
3. Branch to patch or branch to create.
4. Runtime overrides required for reliable repro.
5. What changed in backend behavior:
   - endpoint contract
   - required headers
   - auth requirements
   - status codes
   - response schema
   - business-rule logic
6. Whether the user wants Git changes only, Loadmill UI sync, or both.

## Pending-Change and Sync Tools

Use these tools when the workflow touches Loadmill UI state:
1. `check_test_suite_pending_changes`: inspect whether the suite or its flows have unsynced UI changes.
2. `apply_test_suite_sync`: apply the selected Git branch head to the Loadmill working copy. This overwrites uncommitted suite and flow changes in Loadmill.
3. `update_test_suite_notes`: update suite-level notes.
4. `update_test_suite_flow_notes`: update notes for a specific flow.

Before calling `apply_test_suite_sync`:
1. Confirm suite id, branch, and platform (`github`, `gitlab`, or `bitbucket`).
2. Call `check_test_suite_pending_changes`.
3. If pending changes exist, summarize them and ask for explicit confirmation.
4. Proceed only when the user accepts the overwrite risk.

## Workflow - Updating Existing YAML

1. Identify target suite in `loadmill-suites/`.
2. Capture and restate the backend/API delta that requires test updates.
3. Reproduce failure context with recent run artifacts if available.
4. Identify exact impacted flows and steps.
5. Patch flow logic in place:
   - request payload/query/path updates
   - header/auth updates
   - assertion updates
   - extraction updates
   - flow-control updates
6. Re-check dependent flows because upstream flow changes can affect downstream steps.
7. Validate suite with `validate_test_suite`.
8. Fix all validation errors before run.
9. Commit to a descriptive branch when Git handoff is requested.
10. Ask for required runtime overrides.
11. Run the updated suite using `run_test_suite`.
12. Fetch run details with `get_test_suite_run`.
13. Inspect failing flow runs using `get_test_suite_flow_run`.
14. Summarize failing flow, likely cause, and proposed fix.
15. Iterate until pass or explicit blocker.
16. If the user wants Loadmill UI updated from Git, perform the sync workflow below.

## Workflow - Sync Loadmill From Git

1. Confirm the suite id.
2. Confirm the Git branch whose head should replace the Loadmill working copy.
3. Confirm version-control platform.
4. Call `check_test_suite_pending_changes`.
5. If there are unsynced UI changes:
   - list changed suite/flow ids and descriptions
   - warn that checkout overwrites those changes
   - ask the user to confirm, preserve, or abort
6. Call `apply_test_suite_sync` only after explicit confirmation.
7. Report suite id, branch, platform, applied status, and commit SHA when returned.

## Workflow - Updating Notes

1. Confirm whether the target is suite-level notes or flow-level notes.
2. Confirm suite id and, for flow notes, flow id.
3. Ask for or draft the desired note text.
4. Call `update_test_suite_notes` or `update_test_suite_flow_notes`.
5. Report the updated ids and next recommended action.

Do not edit YAML files only to update Loadmill notes. Notes tools update Loadmill directly.

## Troubleshooting

### New/updated suite not found when running from branch

Cause:
1. Branch does not contain expected YAML commit.
2. Selected run branch does not match patch branch.

Fix:
1. Confirm suite file path and filename format.
2. Confirm commit is on the selected branch.
3. Re-run from that branch.

### Validation fails

Cause:
1. YAML/JSON parse issues.
2. Schema mismatch.
3. Server-side validation rejection.
4. MCP server cannot access the local file path.
5. Schema fetch/compile setup failed.

Fix:
1. Resolve input/parsing issues first.
2. If validation type is `file-access`, retry with `content`.
3. Resolve schema errors next.
4. Resolve server validation errors last.
5. Re-validate before any execution attempt.

### Intermittent or flaky failures

Fix:
1. Re-run to separate persistent failures from transient failures.
2. Compare failing flows across runs.
3. Escalate as flaky if failures are non-deterministic and environment-linked.

### Backend changed and many tests fail at once

Fix:
1. Identify shared contract/header/auth change affecting multiple flows.
2. Apply minimal consistent patch across impacted flows.
3. Validate and run in batches to confirm recovery progressively.

### Sync checkout is risky

Cause:
1. `check_test_suite_pending_changes` reports unsynced Loadmill UI changes.

Fix:
1. Stop before checkout.
2. Ask whether to preserve the UI changes first, proceed with overwrite, or abort.
3. Apply checkout only after explicit confirmation.

## Reporting Template

Use this output shape:
1. `Suite`: file path and suite id.
2. `Backend delta`: what changed in server/API behavior, if applicable.
3. `Change`: what was updated in tests or notes.
4. `Validation`: pass/fail and validation type.
5. `Run`: id and link, when execution occurred.
6. `Failures`: failing flow ids/names only.
7. `Sync`: pending-change result and checkout result, when applicable.
8. `Next`: rerun, open PR, apply sync, or escalate blocker.

## Done Criteria

1. Target bug/update is implemented in YAML or notes.
2. Backend/API behavior change is reflected in requests/assertions when applicable.
3. Validation passes for YAML changes.
4. Post-change run status is reported when execution was requested.
5. Pending UI changes were checked before any Loadmill Git checkout.
6. Remaining risk and next action are explicit.
