# Test Generation

Use this scenario when creating a new suite or adding coverage that does not already exist.

## Intent and Scope

Apply this scenario for requests such as:
1. "Create a new suite for feature X."
2. "Add net-new flows for endpoint Y."
3. "Generate baseline coverage for a new module."
4. "Cover the behavior introduced by this PR."

Do not use this scenario when only patching existing flows. Route those requests to `test-maintenance.md`.

## Mandatory Decision Gate

Before writing test content, determine which path fits the request:
1. `Path A`: add new flow(s) to an existing suite.
2. `Path B`: create a brand new suite.

Always perform this decision process first:
1. Parse the user prompt for domain, feature, endpoint, and intent.
2. Scan existing files in `loadmill-suites/` for matching suites.
3. Use `search_test_suites` or `search_test_flows` when local files are insufficient or stale.
4. Propose the best target:
   - existing suite candidate(s), or
   - reason no suitable suite exists.
5. Ask the user to confirm the target path before creating tests.

Do not proceed with flow/suite creation until the user confirms the selected path.

## Input Checklist

Collect before implementation:
1. Suite purpose and target user journey/API domain.
2. Initial flow list and expected outcomes.
3. Required runtime parameters for execution.
4. Preferred branch name or branch naming pattern.
5. Whether Loadmill UI may contain unsynced changes for the target suite.

## Pre-Edit Sync Check

For Path A, call `check_test_suite_pending_changes` when the suite id is known and the user plans to sync back to Loadmill.

If pending UI changes exist:
1. Report the changed suite/flow ids and descriptions.
2. Explain that applying a Git checkout to Loadmill overwrites those unsynced UI changes.
3. Ask the user whether to continue, preserve the UI changes first, or choose a different target.

Do not apply a Git checkout with `apply_test_suite_sync` until the user explicitly confirms.

## Workflow - Path A (New Flows in Existing Suite)

1. Identify the best existing suite candidate by scanning `loadmill-suites/`.
2. Confirm the suite id from the filename or MCP search result.
3. Run the pre-edit sync check when sync risk matters.
4. Present rationale and ask user confirmation to add flows there.
5. Implement new flow(s) in the confirmed suite.
6. Keep flow ordering intentional because upstream flows can affect downstream flows.
7. Reuse shared flow patterns where appropriate.
8. Validate with `validate_test_suite`.
9. Fix all validation failures before moving forward.
10. Create a descriptive branch and commit changes when the user wants Git handoff.
11. Ask for overrides in `key=value,key2=value2` format if execution is requested.
12. Run the suite from the feature branch using `run_test_suite` when branch-specific YAML must be tested.
13. Fetch status/details with `get_test_suite_run`.
14. If needed, inspect failing flow runs with `get_test_suite_flow_run`.
15. Share run link and concise pass/fail summary.
16. If the user wants Loadmill UI updated from Git, use `apply_test_suite_sync` only after the pending-change check and explicit confirmation.

## Workflow - Path B (New Suite)

1. Explain why no existing suite is a good fit and ask user confirmation.
2. Create a new empty suite with `create_new_test_suite`.
3. Capture the returned suite id.
4. Create `loadmill-suites/{suite_name}.{suite_id}.yaml`.
5. Implement initial flows and keep flow ordering intentional.
6. Validate with `validate_test_suite`.
7. Fix all validation failures before moving forward.
8. Create a descriptive branch and commit changes when the user wants Git handoff.
9. Ask for overrides in `key=value,key2=value2` format if execution is requested.
10. Run suite from the feature branch using `run_test_suite`.
11. Fetch status/details with `get_test_suite_run`.
12. If needed, inspect failing flow runs with `get_test_suite_flow_run`.
13. Share run link and concise pass/fail summary.
14. If the user wants Loadmill UI updated from Git, use `apply_test_suite_sync` after confirming the target branch and platform.

## Naming and Layout

1. Keep suite filename format exactly `{suite_name}.{suite_id}.yaml`.
2. Keep suite name clear and stable; avoid ambiguous abbreviations.
3. Reuse shared flows when possible instead of duplicating logic.
4. Keep flows deterministic and explicit with assertions and extractions.
5. Use existing files in `loadmill-suites/` as formatting/style references.

## Validation and Quality Bar

1. Require a full validation pass before declaring completion.
2. Prefer `validate_test_suite` with `path` when MCP can read the file.
3. Use `content` when MCP cannot access the local path or returns `validationType: file-access`.
4. Treat schema, server-side, file-access, and schema-setup failures as blockers unless the user explicitly accepts the limitation.
5. Resolve parse/input errors first, then schema/server issues.
6. Ensure each new flow has clear success criteria.
7. Ensure user-approved target (existing suite vs new suite) is recorded before edits.

## Common Failure Modes

### Run returns not found

Cause:
1. Suite file is not committed/pushed on selected branch.
2. Wrong suite id or branch selected in run call.
3. New suite exists in Loadmill but the selected branch does not contain the expected YAML filename.

Fix:
1. Verify file exists with exact `{suite_name}.{suite_id}.yaml` naming.
2. Verify commit is on the selected branch.
3. Re-run using correct suite id and branch.

### Validation cannot read file

Cause:
1. MCP server runs in a different filesystem context.
2. Path is relative to a different working directory.

Fix:
1. Retry `validate_test_suite` with raw suite YAML/JSON in `content`.
2. Report `validationType: file-access` if it remains blocked.

### Validation passes locally but run still fails

Cause:
1. Runtime data/environment mismatch.
2. Missing/incorrect override parameters.

Fix:
1. Reconfirm required overrides with user.
2. Re-run with corrected overrides.

## Done Criteria

1. Suite YAML exists in `loadmill-suites/`.
2. Validation passes with `validationType: complete`.
3. Run result is shared when execution was requested.
4. Pending UI changes were checked before any Git checkout into Loadmill.
5. Next action is explicit: rerun, PR, merge follow-up, or Loadmill sync.
