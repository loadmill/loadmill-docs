# Test Runner

Use this scenario for one-off runs, selected-flow runs, and continuous regression checks while developing a feature.

Primary goals:
1. Run relevant suites, selected flows, or regression test plans while development is in progress.
2. Provide fast feedback loops and tight failure triage.
3. Keep developers shipping while guarding against cross-feature regressions.

## Inputs to Collect

1. Feature, ticket, suite, or plan context.
2. Target suite id, flow ids, or plan id.
3. Target labels for plan runs, for example `auth`, `billing`, `checkout`.
4. Optional plan filter text if multiple plans exist.
5. Override parameters in `key=value,key2=value2` format.
6. Desired cadence: one-off, after each commit slice, or pre-PR gate.
7. Whether branch-specific YAML must be tested.

## MCP Behavior Notes

Ground workflow in current MCP implementation:
1. `run_test_suite` accepts:
   - `id` (suite id)
   - `overrideParameters` (comma-separated string)
   - `branch` (optional Git branch for branch-specific suite configuration)
   - `flows` (optional array of flow ids to run only selected flows)
2. `run_test_suite` cannot combine `branch` and `flows`.
3. `get_test_suite_run` returns suite-run state and flow run ids.
4. `get_test_suite_flow_run` returns flow-level run evidence.
5. `run_test_plans` accepts:
   - `id` (plan id)
   - `labels` (array)
   - `overrideParameters` (comma-separated string)
6. `get_test_plan_run` returns plan-run state and metadata.
7. `get_labels` returns label ids and descriptions.
8. `overrideParameters` parsing is strict and fails on malformed `key=value` pairs.

## Preflight Protocol

Execute before every run:
1. Confirm whether the run target is a suite, selected suite flows, or a test plan.
2. Confirm suite id or plan id.
3. Confirm exact flow ids for selected-flow runs.
4. Confirm exact labels for plan runs.
5. Confirm override parameter string format.
6. Confirm whether this is a baseline run or rerun.
7. Confirm whether branch-specific YAML must be used.

If labels are unclear, call `get_labels` and propose a minimal high-signal set.

If the user asks to run selected flows from a branch, explain that MCP does not support combining `branch` and `flows`; ask whether to run the whole suite from the branch or selected flows from the current Loadmill working copy.

## Workflow - Suite Run

1. Resolve the suite with `search_test_suites` or the suite id from the YAML filename.
2. Confirm suite id, branch if any, and overrides.
3. Trigger execution with `run_test_suite`.
4. Track status with `get_test_suite_run` until terminal state or until you report an explicit next poll time.
5. On failure, inspect flow run ids with `get_test_suite_flow_run` as needed.
6. Report run id, run link, status, failures, and next step.

## Workflow - Selected Flow Run

1. Resolve candidate flows with `search_test_flows` when ids are not already known.
2. Confirm suite id and exact flow id list.
3. Confirm no branch argument will be used.
4. Trigger execution with `run_test_suite` using `flows`.
5. Track status with `get_test_suite_run`.
6. Inspect failing selected flow runs with `get_test_suite_flow_run`.
7. Report only the selected-flow results and whether a full suite rerun is recommended.

## Workflow - Plan Run by Labels

1. Resolve candidate plans with `search_test_plans`.
2. Confirm plan id and label set.
3. Trigger execution with `run_test_plans` using labels and overrides.
4. Track status with `get_test_plan_run` until terminal state or explicit next poll time.
5. Report summary with run id and run link.
6. On failure, identify failing suites and then drill into flow-level evidence when needed.
7. If additional detail is required, query recent flow runs with `search_test_suite_runs`.
8. Present likely cause and next fix action.
9. Offer fast rerun loop with the same labels after code changes.

## Execution Guardrails

1. Never run a plan without explicit label confirmation.
2. Validate override parameter format before running.
3. Prefer smaller, high-signal label sets for fast feedback loops.
4. Use selected-flow runs for focused debugging when branch-specific YAML is not required.
5. Use branch suite runs when testing YAML changes from Git.
6. Keep reports concise and actionable for developers in active coding flow.
7. If run is still in progress, report partial state and explicit next poll time.
8. For repeat failures, recommend maintenance workflow to patch suite or feature behavior.

## Suggested Cadence During Feature Work

1. Run once after first implementation slice.
2. Re-run after each meaningful change set.
3. Run selected flows while debugging a specific failure.
4. Run one final suite or plan pass before PR handoff.
5. Re-run immediately after a fix to a previously failing flow.

## Failure Triage Protocol

When a run fails:
1. List failing suites first.
2. List failing flows second.
3. Classify likely cause:
   - product regression
   - test fragility
   - environment/config issue
4. Suggest exactly one highest-value next action.
5. Include rerun recommendation and expected confirmation signal.

When available, use the MCP `investigate_failed_test` prompt for detailed failure reasoning, but do not depend on it when direct run evidence is sufficient.

## Output Format

1. `Target`: suite, selected flows, or plan.
2. `Id`: suite id or plan id.
3. `Labels`: exact list used for plan runs, or `none`.
4. `Flows`: exact selected flow ids, or `all`.
5. `Branch`: branch used, or `none`.
6. `Overrides`: exact override string used, or `none`.
7. `Status`: pass/fail/running.
8. `Failures`: failing suites/flows only.
9. `Link`: suite or plan run URL.
10. `Next step`: rerun, investigate, maintenance fix, or merge gate decision.

## Example Operator Prompts

1. "Run regression for feature checkout with labels `checkout,payments`."
2. "Use the same labels as last run and rerun after my latest change."
3. "Run quick auth regression and tell me only blockers."
4. "Run only flow ids X and Y from suite Z."
5. "Run this suite from my feature branch."

## Done Criteria

1. Requested run was triggered with confirmed ids, labels, flows, branch, and overrides.
2. Current run status is reported with run link.
3. Failures are triaged to actionable next step.
4. Rerun plan is proposed when appropriate.
