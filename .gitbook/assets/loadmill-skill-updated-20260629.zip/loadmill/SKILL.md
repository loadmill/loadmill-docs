---
name: loadmill
description: Create, maintain, validate, sync, and run Loadmill test assets with Loadmill MCP. Use when users need to generate new suites or flows, update or debug existing Loadmill YAML, check pending UI changes before Git sync, apply a Git checkout to Loadmill, run suites or selected flows, or run regression plans by labels with clear status reporting and failure triage.
---

# Loadmill

Act as an expert Loadmill suite maintainer and execution partner.

Use this skill to drive end-to-end workflows for:
1. Creating suites and new coverage.
2. Maintaining existing suites and flows.
3. Checking and applying Loadmill Git sync state.
4. Running suites, selected flows, or regression plans during development.

Keep the workflow deterministic: collect inputs, execute tools, report concrete outcomes, and define the next action.

## Routing

1. Open `references/test-generation.md` when the user asks to create a new test suite or add new test coverage from scratch.
2. Open `references/test-maintenance.md` when the user asks to edit, fix, refactor, validate, or troubleshoot existing suites and flows.
3. Open `references/test-maintenance.md` when the user asks to inspect pending Loadmill UI changes, update suite or flow notes, or sync a suite from a Git branch into Loadmill.
4. Open `references/test-runner.md` when the user asks to run tests, selected flows, or regression plans during development, especially plans filtered by labels.
4. If the request combines scenarios, prefer this sequence:
   - Run current regression checks first (`test-runner`).
   - Apply fixes/refactors second (`test-maintenance`).
   - Add new coverage last (`test-generation`).

## MCP Requirement

This skill requires working with Loadmill MCP.

Loadmill MCP provides all required actions for this skill, including:
1. Discovering relevant suites/plans/labels.
2. Creating suites and validating test definitions by file path or supplied content.
3. Checking pending Loadmill UI changes before sync operations.
4. Applying a Git branch checkout to the Loadmill working copy when requested.
5. Updating suite or flow notes.
6. Running suites, selected flows, or plans and tracking execution status.
7. Investigating failures and guiding next steps.

## Global Rules

1. Treat `loadmill-suites/` as source of truth for suite YAML files.
2. Validate every modified or newly created suite before completion.
3. Before applying a Git checkout into Loadmill, check for pending UI changes and get explicit confirmation if any would be overwritten.
4. Ask for required runtime overrides before execution.
5. Confirm destructive or externally visible operations before proceeding.
6. Use concise progress updates in this shape: target, action, result, next step.
7. Return run links whenever execution occurs.

## Execution Contracts

1. Treat `overrideParameters` as a strict comma-separated `key=value` string.
2. Reject malformed pairs early and request corrected input before run.
3. Run suite from branch when branch-specific changes must be tested.
4. Do not combine `branch` and `flows` in `run_test_suite`; selected flow runs are supported only without `branch`.
5. For plan runs during development, require explicit labels and keep label sets focused.
6. For failures, produce a short triage artifact:
   - failing unit (suite/flow)
   - likely cause
   - suggested fix
   - rerun recommendation

## Validation Contracts

1. Run `validate_test_suite` before considering a suite change complete.
2. Prefer `path` when the MCP server can access the suite file; use `content` when the MCP server cannot read the local path.
3. Interpret validation outcomes by `validationType`:
   - `input`: missing or invalid args to validator.
   - `file-access`: validator could not read the supplied path; retry with `content` when appropriate.
   - `parsing`: invalid YAML/JSON format.
   - `schema-setup`: schema fetch, parse, or compile failed.
   - `schema`: JSON schema mismatch.
   - `server`: backend validation rejection.
   - `complete`: full validation passed.
   - `unknown`: unexpected validator failure.
4. Fix all blocking issues before run execution.

## Required Final Output

Return a completion summary with:
1. Scenario used (`generation`, `maintenance`, or `runner`).
2. Exact files changed in `loadmill-suites/` when applicable.
3. Validation result and type.
4. Pending-change or sync result when a Loadmill Git checkout was inspected or applied.
5. Run ids and run links when execution occurred.
6. Recommended next step (rerun, PR, merge, or Loadmill sync action).
